void programmain(){

		

		while(1){
	vidptr[0] = 'X';			

//printLine("x");
	}
}
