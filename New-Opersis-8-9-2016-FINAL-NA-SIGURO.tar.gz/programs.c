void prog1(){
		
		while(1){
	vidptr[0] = 'x';			

	}
}

void prog2(){
	
	while(1){
vidptr[0] = 'y';	
}

}

