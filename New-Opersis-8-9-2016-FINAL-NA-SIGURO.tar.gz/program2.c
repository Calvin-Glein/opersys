void program2(){
int count = 0;
	
	while(count < 100){
     printLine("PROGRAM2 ");
	move_cursor(i/2);	
	sleepDelay(500);
	count++;
}

while(1);

}

