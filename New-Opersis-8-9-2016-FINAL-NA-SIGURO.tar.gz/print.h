

unsigned int i =0;
unsigned int j =0; 
char *vidptr = (char*)0xb8000; 	//video mem begins here.



void clrscr(){
	i = 0;
	j = 0;

	/* this loops clears the screen
	* there are 25 lines each of 80 columns; each element takes 2 bytes */
	while(j < 80 * 25 * 2) {
		/* blank character */
		vidptr[j] = ' ';
		/* attribute-byte - light grey on black screen */
		vidptr[j+1] = 0x07; 		
		j = j + 2;
	}

	i = 0;
	j = 0;

}






void scrolldown(){
char *temp;
int k=0;
int l=160;


	while(k < 80 * 25 * 2) {
		/* blank character */
		temp[k] = ' ';
		/* attribute-byte - light grey on black screen */
		temp[k+1] = 0x07; 		
		k = k + 2;
	}
	k=0;

	while(k < 80 * 24 * 2) {
		/* blank character */
		temp[k]=vidptr[l];
		/* attribute-byte - light grey on black screen */
		temp[k+1] = 0x07; 		
		k = k + 2;
		l = l+2;
	}

	clrscr();

	k=0;

	while(k < 80 * 24 * 2) {
		/* blank character */
		vidptr[k]=temp[k];
		/* attribute-byte - light grey on black screen */
		vidptr[k+1] = 0x07; 		
		k = k + 2;
	}






}


void sleepDelay(int n){
	int b = n*10000;
	int a = 0;
	while(a<b){
		a++;
	}
}




void checkDirectScroll(){
 
 if(i == (80*24*2)){

scrolldown();


 } else;


}




void printc(char ch){
vidptr[i] = ch; 
vidptr[i+1] = 0x07;
i+=2;

checkDirectScroll();

}


void prints(char *str){   //function to print string

	char *str1 = str;
	/* this loop writes the string to video memory */
	while(str1[j] != '\0') {
		/* the character's ascii */
		vidptr[i] = str1[j];
		/* attribute-byte: give character black bg and light grey fg */
		vidptr[i+1] = 0x07;
		++j;
		i = i + 2;
	}

	checkDirectScroll();

}




void printi(int integer)
{

int temp=0;
	int converter = 0;
	char *tempStr ="                         "; //empty string of 25 spaces for number string
	int ctr=0;

if(integer<=9)
printc(integer+'0');

else{


	while(integer != 0){
		converter = integer%10;
	
		tempStr[ctr]=(converter+'0');

		integer /= 10;
		ctr++;
}
	ctr--;
	while(ctr>=0){
		printc(tempStr[ctr]);
		ctr--;

	}



}
}

void printh(int integer)
{
	unsigned int k = 0;
	char *finalHex = "";
	int temp=0;
	char *tempStr = "";
	int converter = 0;
	char tempChar = ' ';
	while(integer != 0){
		temp = integer%16;
		integer /= 16;
		if(temp ==0)
		{
			tempChar = '0';
		}
		if(temp ==1)
		{
			tempChar = '1';
		}
		if(temp ==2)
		{
			tempChar = '2';
		}
		if(temp ==3)
		{
			tempChar = '3';
		}
		if(temp ==4)
		{
			tempChar = '4';
		}
		if(temp ==5)
		{
			tempChar = '5';
		}
		if(temp ==6)
		{
			tempChar = '6';
		}
		if(temp ==7)
		{
			tempChar = '7';
		}
		if(temp ==8)
		{
			tempChar = '8';
		}
		if(temp ==9)
		{
			tempChar = '9';
		}
		if(temp ==10)
		{
			tempChar = 'A';
		}
		if(temp ==11)
		{
			tempChar = 'B';
		}
		if(temp ==12)
		{
			tempChar = 'C';
		}
		if(temp ==13)
		{
			tempChar = 'D';
		}
		if(temp ==14)
		{
			tempChar = 'E';
		}
		if(temp ==15)
		{
			tempChar = 'F';
		}
		tempStr[k] = tempChar;
		k = k+1;
		tempChar = ' ';
	}
	tempStr[k] = '\0';
	k--;
	int l;
	l=k;
	j=0;
	while(tempStr[j]!='\0'){
		printc(tempStr[k]);
		j++;
		k--;
	}

	prints(finalHex);	

}




void printLine(char* string)
{
	const char *str = string;
	j = 0;




	
	/* this loop writes the string to video memory */
	while(str[j] != '\0') {
		/* the character's ascii */
		vidptr[i] = str[j];
		/* attribute-byte: give character black bg and light grey fg */
		vidptr[i+1] = 0x07;
		++j;
 		i = i + 2;
	}


checkDirectScroll();


}

unsigned char map[128] =
{
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8',	/* 9 */
  '9', '0', '-', '=', '\b',	/* Backspace */
  '\t',			/* Tab */
  'q', 'w', 'e', 'r',	/* 19 */
  't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',	/* Enter key */
    0,			/* 29   - Control */
  'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',	/* 39 */
 '\'', '`',   0,		/* Left shift */
 '\\', 'z', 'x', 'c', 'v', 'b', 'n',			/* 49 */
  'm', ',', '.', '/',   0,				/* Right shift */
  '*',
    0,	/* Alt */
  ' ',	/* Space bar */
    0,	/* Caps lock */
    0,	/* 59 - F1 key ... > */
    0,   0,   0,   0,   0,   0,   0,   0,
    0,	/* < ... F10 */
    0,	/* 69 - Num lock*/
    0,	/* Scroll Lock */
    0,	/* Home key */
    0,	/* Up Arrow */
    0,	/* Page Up */
  '-',
    0,	/* Left Arrow */
    0,
    0,	/* Right Arrow */
  '+',
    0,	/* 79 - End key*/
    0,	/* Down Arrow */
    0,	/* Page Down */
    0,	/* Insert Key */
    0,	/* Delete Key */
    0,   0,   0,
    0,	/* F11 Key */
    0,	/* F12 Key */
    0,	/* All other keys are undefined */
};		
