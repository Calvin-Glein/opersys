int global =0;





void test(){
	int x=0;
	x++;
	test();
}






void main(){
	char ex = 0, why;

	test();

}



EBP contains the variables of a function.
Above EBP contains the global variables.
The first thing that gets called is EIP.
EIP stores memory location of the code or function to be called.
Push EIP before calling a function.
Unang gagawin ng call is to back up yung EBP dun sa stack.


stack

esp ->
		________
		________
		________
		old EBP   <- EBP
		old ESP   <- ESP

top of stack (esp) nipoint sa EBP
ilalagay yung ebp sa register





