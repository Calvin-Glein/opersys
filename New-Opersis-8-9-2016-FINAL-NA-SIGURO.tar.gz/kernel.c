                    #include "macros.h"
                    #include "print.h"
                    #include "gdt.h"
                    #include "idt.h"
                    #include "isr.h"
                    #include "irq.h"
                    #include "string.h"
                    //#include "programs.c"
		    #include "program1.c"
		    #include "program2.c"
		    #include "programmain.c"

                    int pos; 
                    char readLine[80];
                    char* tempscr;
		    char* tempscr1; 
		    int cursorTemp = 0;
		    int cursorTempOn = 0;
		    int lineNumTemp = 0;
                    int isreading = 0;
                    int enterKeyPress = 0;

                    int screensaverOn = 0;
                    int status;
                    int solveCounter =0;

                    int lineNumber = 1;
                    int twenty = 20;
                    int scsvVal = 100;
                    //char* tempz;
		    extern void asmtest();
		    int stack1[1023];
			int stack2[1023];
			int stack3[1023];
			int lastESP[3]; //0 for main, 1 for prog1, 2 for prog2
			int prog1flag = 0;
			int prog2flag = 0;
			int prog3flag = 0;
			int progmainflag = 0;
			int currProcess = 0;
			int mainEIP;

			int prog1Quant = 50;
			int prog1Switch = 0;
			int prog2Quant = 50;	
			int prog2Switch = 0;
			int progTrigger = 0;
			int progSRFlag = 0;

                    void move_cursor(int position)
                    {
                        outb(0x3D4, 0x0F);
                        outb(0x3D5, position & 0xFF);

                        outb(0x3D4, 0x0E);
                        outb(0x3D5, position >> 8&0xFF);
                    }

                    void Solve()
                    {
                        int i=0;
                        int num1=0;
                        int num2=0;
                        int operand=0;
                        int final=0;


                        while(readLine[i]==' ')
                        {
                            i++;
                        }


                        while(readLine[i]=='1'||readLine[i]=='2'||readLine[i]=='3'||
                              readLine[i]=='4'||readLine[i]=='5'||readLine[i]=='6'||
                              readLine[i]=='7'||readLine[i]=='8'||readLine[i]=='9'||
                              readLine[i]=='0')
                        {

                            num1 = num1*10;
                            num1 += (readLine[i]-'0');

                            i++;
                        }

                        while(readLine[i]==' ')
                        {
                            i++;
                        }


                        if(readLine[i]=='-')
                        {
                            operand = 1;
                        }
                        else if(readLine[i]=='=')
                        {
                            operand=2;
                        }
                        else if(readLine[i]=='+')
                        {
                            operand=2;
                        }

                        i++;

                        while(readLine[i]==' ')
                        {
                            i++;
                        }

                        while(readLine[i]!='\0')
                        {

                            if(readLine[i]=='1'||readLine[i]=='2'||readLine[i]=='3'||
                               readLine[i]=='4'||readLine[i]=='5'||readLine[i]=='6'||
                               readLine[i]=='7'||readLine[i]=='8'||readLine[i]=='9'||
                               readLine[i]=='0')
                            {
                                
                                num2 = num2*10;
                                num2 += (readLine[i]-'0');
                            }

                            i++;
                        } 

                        while(readLine[i]==' ')
                        {
                            i++;
                        }

                        switch(operand)
                        {
                            case 1: final = (num1-num2);
                                    printc('=');
                                    printi(final);
                                    break;

                            case 2: final = (num1+num2);
                                    printc('=');
                                    printi(final);
                                    break;
                        }
                    }


                    void resetRead()
                    {
                        int c=0;

                        for(c=0;c<80;c++)
                        {
                            readLine[c]='\0';
                        }
                    }

                    void doProgram()
                    {
                        if(strcmp(readLine, "prog1")==0)
                        {
                         //   asmtest();
                        }
                        else if(strcmp(readLine, "prog2")==0)
                        {
                        //    program2();
                        }   
                    }

                    void backupscr()
                    {
                        int ct = 0;

                        unsigned int j = 0;
                        while(j<80*2*25){
                            tempscr[j] = ' ';
                            tempscr[j+1] = 0x07;
                            j = j+2;
                        }

                        while(ct<(80*25*2))
                        {
                            tempscr[ct] = vidptr[ct];
                            ct++;
                        }
		              	lineNumTemp = lineNumber;
                    }

                    void backupscrP1()
                    {
                        int ct = 0;

                        unsigned int j = 0;
                        while(j<80*2*25){
                            tempscr1[j] = ' ';
                            tempscr1[j+1] = 0x07;
                            j = j+2;
                        }

                        while(ct<(80*25*2))
                        {
                            tempscr1[ct] = vidptr[ct];
                            ct++;
                        }
		              	lineNumTemp = lineNumber;
                    }

                    void restorscr()
                    {
                        int ct = 0;

                        while(ct<(80*25*2))
                        {
                           vidptr[ct] = tempscr[ct];
                           ct++;
                        }
                    }

                    void gets(char *result)
                    {
                        isreading=1;
                       
                        if(enterKeyPress == 1)
                        {
                            isreading = 0;
                        }

                        while(isreading);

                        int a=0;
                        for(a=0;a<strlen(readLine);a++)
                        {
                            result[a]=readLine[a];
                        }
                        result[a]='\0';
                        enterKeyPress = 0;
                    }

                    void timer_handler(struct regs *r)
                    {   
                        if(scsvVal!= 0)
                            scsvVal--;
                        if(scsvVal == 0)
                        {
            			    if(screensaverOn == 0)
            		        {      
                                	backupscr();
		                        screensaverOn = 1;
        			        cursorTemp = i;
        				clrscr();
        		                lineNumber = 1;
        		                prints("SCREENSAVEMORE");
        				        move_cursor(i/2);
            		      	}
                        }


			
			if((prog1Switch == 1) && (prog2Switch == 1))
				{

					if(progTrigger == 1){
						if(progSRFlag == 1){
						restorscr();
						progSRFlag = 0;
						move_cursor(i/2);
						}

						doProg1(r);
/*SKETCHY SHIT*/
						if(prog1Quant!=0)
							prog1Quant--;
						if(prog1Quant == 0){
							backupscr();
							progTrigger = 2;
							prog1Quant = 50;
							progSRFlag = 1;
							clrscr();}
						}

					if(progTrigger== 2){

						doProg2(r);

						if(prog2Quant!=0)
							prog2Quant--;
						if(prog2Quant == 0){
							progTrigger = 1;
							prog2Quant = 50;}
						}
						
				}

			else if(prog1Switch == 1)
				{
					doProg1(r);
					progTrigger = 1;
				}

			else if(prog2Switch == 1)
				{
					doProg2(r);
					progTrigger = 2;
				}



        
                    }

			void doProg1(struct regs *r){

					lastESP[currProcess] = r->nextESP;
					currProcess = 1;
					r->nextESP = lastESP[currProcess];
					
			}

			void doProg2(struct regs *r){
					
					lastESP[currProcess] = r->nextESP;
					currProcess = 2;
					r->nextESP = lastESP[currProcess];

			}

			void doReturnMain(struct regs *r){

					lastESP[currProcess] = r->nextESP;
					currProcess = 0;
					r->nextESP = lastESP[currProcess];
					prog1Switch = 0;
					prog2Switch = 0;
					restorscr();
					move_cursor(i/2);

			}			


                    void key_handler(struct regs *r)
                    {
                        char key; 
                        status =inb(0x64);
     
                        if(status & 0x01)
                        {
                            key = inb(0x60);

                            if(key<0);
                            else
                            {

                                if(screensaverOn == 1)
                                {
		                    restorscr();
		                    lineNumber = lineNumTemp;
				}

                                if(key==28)
                                {    
                                    enterKeyPress = 1;
                                    //gets(tempz);
                                    //doProgram(); 
                                    Solve();
                                    resetRead();
                                    solveCounter = 0;

				    if(screensaverOn == 1)
				    {
					i = cursorTemp;
				    }				
				    else
				    {
		    			i = lineNumber * 180 - twenty;
				    }

                                    printLine("MyOS>");
                                    move_cursor(i/2);
                                    lineNumber++;
                                    scsvVal = 100;
				    screensaverOn = 0;

                                    // if(twenty=160){
                                    //  twenty = 20;
                                    // }
                                    // else

                                    twenty = twenty + 20;

                                    if(lineNumber==25)
                                    {
				        scrolldown();
                                        lineNumber = 24;
                                        twenty = twenty - 20;

                                        i = ((80*24*2));
                                        printLine("MyOS>");
                                        scsvVal = 100;
                                    }
                                }


                                else if(key==59)
                                {
					
				    	scsvVal = 100;

						if(prog1flag == 0){
						stack1[1023] = r->ss;
						stack1[1022] = r->useresp;
						stack1[1021] = r->eflags;
						stack1[1020] = r->cs;
						stack1[1019] = program1;
						stack1[1018] = r->err_code;
						stack1[1017] = r->int_no;
						stack1[1016] = r->eax;
						stack1[1015] = r->ecx;
						stack1[1014] = r->edx;
						stack1[1013] = r->ebx;
						stack1[1012] = r->esp;
						stack1[1011] = r->ebp;
						stack1[1010] = r->esi;
						stack1[1009] = r->edi;
						stack1[1008] = r->ds;
						stack1[1007] = r->es;
						stack1[1006] = r->fs;
						stack1[1005] = r->gs;

						lastESP[1] = &stack1[1005];
			
						prog1flag = 1;
						}

                                	backupscr();
		                        screensaverOn = 1;
        			        cursorTemp = i;
        		                lineNumber = 1;
					prog1Switch = 1;			
				
					//doProg1(r);

				}
                                else if(key==60)
                                {
				    	scsvVal = 100;

					if(prog2flag == 0){

					stack2[1023] = r->ss;
					stack2[1022] = r->useresp;
					stack2[1021] = r->eflags;
					stack2[1020] = r->cs;
					stack2[1019] = program2;
					stack2[1018] = r->err_code;
					stack2[1017] = r->int_no;
					stack2[1016] = r->eax;
					stack2[1015] = r->ecx;
					stack2[1014] = r->edx;
					stack2[1013] = r->ebx;
					stack2[1012] = r->esp;
					stack2[1011] = r->ebp;
					stack2[1010] = r->esi;
					stack2[1009] = r->edi;
					stack2[1008] = r->ds;
					stack2[1007] = r->es;
					stack2[1006] = r->fs;
					stack2[1005] = r->gs;
					lastESP[2] = &stack2[1005];

					prog2flag = 1;

					}

                                	backupscr();
		                        screensaverOn = 1;
        			        cursorTemp = i;
        		                lineNumber = 1;
					prog2Switch = 1;

					//doProg2(r);
                                }
                                
				else if(key == 61)
				{

					doReturnMain(r);
				}

                                else
                                {
                				    if(screensaverOn == 1)
	        				    i = cursorTemp;
	        				    printc(map[key]);
                                    scsvVal = 100;
                                    move_cursor(5);
                                    screensaverOn = 0;
                                    move_cursor(i/2);
                                    readLine[solveCounter] = map[key];
                                    solveCounter++;
                                }
                            }
                        }
                    }



                    /* Sets up the system clock by installing the timer handler
                    *  into IRQ0 */
                    void handlers_install()
                    {
                        /* Installs 'timer_handler' to IRQ0 */
                        irq_install_handler(0, timer_handler);
                        irq_install_handler(1, key_handler);

                    }

                    /* Should be called by main. This will setup the special GDT
                    *  pointer, set up the first 3 entries in our GDT, and then
                    *  finally call gdt_flush() in our assembler file in order
                    *  to tell the processor where the new GDT is and update the
                    *  new segment registers */
                    void gdt_install()
                    {
                        /* Setup the GDT pointer and limit */
                        gp.limit = (sizeof(struct gdt_entry) * 3) - 1;
                        gp.base = &gdt;

                        /* Our NULL descriptor */
                        gdt_set_gate(0, 0, 0, 0, 0);

                        /* The second entry is our Code Segment. The base address
                        *  is 0, the limit is 4GBytes, it uses 4KByte granularity,
                        *  uses 32-bit opcodes, and is a Code Segment descriptor.
                        *  Please check the table above in the tutorial in order
                        *  to see exactly what each value means */
                        gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);

                        /* The third entry is our Data Segment. It's EXACTLY the
                        *  same as our code segment, but the descriptor type in
                        *  this entry's access byte says it's a Data Segment */
                        gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);

                        /* Flush out the old GDT and install the new changes! */
                        gdt_flush();
                    }

                    /* Installs the IDT */
                    void idt_install()
                    {
                        int i=0;
                        /* Sets the special IDT pointer up, just like in 'gdt.c' */
                        idtp.limit = (sizeof (struct idt_entry) * 256) - 1;
                        idtp.base = &idt;

                        /* Clear out the entire IDT, initializing it to zeros */
                        memset(&idt, 0, sizeof(struct idt_entry) * 256);

                        // isrs_install();
                        irq_install(0, key_handler);
                        handlers_install();

                        /* Points the processor's internal register to the new IDT */
                        idt_load();
                    }

                    /* All of our Exception handling Interrupt Service Routines will
                    *  point to this function. This will tell us what exception has
                    *  happened! Right now, we simply halt the system by hitting an
                    *  endless loop. All ISRs disable interrupts while they are being
                    *  serviced as a 'locking' mechanism to prevent an IRQ from
                    *  happening and messing up kernel data structures */
                    void fault_handler(struct regs *r)
                    {
                        /* Is this a fault whose number is from 0 to 31? */
                        if (r->int_no < 32)
                        {
                            /* Display the description for the Exception that occurred.
                            *  In this tutorial, we will simply halt the system using an
                            *  infinite loop */
                            prints(exception_messages[r->int_no]);
                            prints(" Exception. System Halted!\n");
                            for (;;);
                        }
                    }
			
		    void init()
		    {
                        gdt_install();
                        idt_install();
		    }

                    void kmain(void)
                    {
			init();
                        clrscr();
                        printLine("MyOS>");
                        move_cursor(5);
			//while(1);

                    }
