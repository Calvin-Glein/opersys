void program1(){

int count = 0;

	while(count < 50){
    	printLine("PROGRAM1 ");
	move_cursor(i/2);
    	sleepDelay(1000);
	count++;
	}

	while(1);

}
